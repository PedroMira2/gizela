// ============================================================================
// pilatGZ - Site Configuration
// Academia de Pilates, Yoga & Bem-Estar - Aveiro, Portugal
// ============================================================================

export interface SiteConfig {
  title: string;
  description: string;
  language: string;
}

export const siteConfig: SiteConfig = {
  title: "pilatGZ - Pilates, Yoga & Bem-Estar | Aveiro",
  description: "Descubra o equilíbrio entre corpo e mente na pilatGZ. Pilates, Yoga e Barre em Aveiro. Aulas para todos os níveis. Agende a sua aula experimental.",
  language: "pt-PT",
};

// ============================================================================
// Navigation Configuration
// ============================================================================

export interface NavItem {
  label: string;
  href: string;
}

export interface NavigationConfig {
  logo: string;
  items: NavItem[];
}

export const navigationConfig: NavigationConfig = {
  logo: "pilatGZ",
  items: [
    { label: "Home", href: "#hero" },
    { label: "Sobre", href: "#about" },
    { label: "Modalidades", href: "#modalities" },
    { label: "Reservas", href: "#reservas" },
    { label: "Contactos", href: "#contact" },
  ],
};

// ============================================================================
// Hero Section Configuration
// ============================================================================

export interface HeroConfig {
  title: string;
  subtitle: string;
  backgroundImage: string;
  servicesLabel: string;
  copyright: string;
}

export const heroConfig: HeroConfig = {
  title: "Celebre o Movimento",
  subtitle: "Descubra o equilíbrio entre corpo e mente na pilatGZ",
  backgroundImage: "/images/hero-main.jpg",
  servicesLabel: "Pilates • Yoga • Barre",
  copyright: "© 2024 pilatGZ",
};

// ============================================================================
// About Section Configuration
// ============================================================================

export interface AboutConfig {
  titleLine1: string;
  titleLine2: string;
  description: string;
  image1: string;
  image1Alt: string;
  image2: string;
  image2Alt: string;
  authorImage: string;
  authorName: string;
  authorBio: string;
}

export const aboutConfig: AboutConfig = {
  titleLine1: "Onde o Movimento",
  titleLine2: "Encontra a Serenidade",
  description: "Na pilatGZ, acreditamos que cada movimento é uma oportunidade de reconexão consigo mesmo. O nosso espaço em Aveiro foi criado para ser um refúgio de bem-estar, onde o Pilates e o Yoga se encontram para transformar vidas. Com instrutores certificados e uma metodologia única, acompanhamos a sua jornada de transformação pessoal, respeitando o ritmo e as necessidades de cada corpo.",
  image1: "/images/about-1.jpg",
  image1Alt: "Aula de Yoga na pilatGZ",
  image2: "/images/modality-pilates.jpg",
  image2Alt: "Aula de Pilates na pilatGZ",
  authorImage: "/images/instructor-1.jpg",
  authorName: "Gabriela Ferreira",
  authorBio: "Fundadora e instrutora principal da pilatGZ, com mais de 15 anos de experiência em Pilates e Yoga. A sua missão é criar um espaço onde cada pessoa possa descobrir o poder do movimento consciente.",
};

// ============================================================================
// Modalities Section Configuration
// ============================================================================

export interface ModalityItem {
  id: string;
  title: string;
  description: string;
  image: string;
  benefits: string[];
  duration: string;
  intensity: string;
}

export interface ModalitiesConfig {
  tag: string;
  title: string;
  subtitle: string;
  modalities: ModalityItem[];
}

export const modalitiesConfig: ModalitiesConfig = {
  tag: "MODALIDADES",
  title: "Encontre a Sua Prática",
  subtitle: "De Pilates a Yoga, oferecemos modalidades para todos os níveis e objetivos. Cada aula é uma oportunidade de crescimento.",
  modalities: [
    {
      id: "pilates-mat",
      title: "Pilates Mat",
      description: "Fortaleça o core e melhore a postura com exercícios de controlo e precisão. Pilates em mat utiliza o peso do corpo e pequenos equipamentos para criar um corpo longo, tonificado e alinhado.",
      image: "/images/modality-pilates.jpg",
      benefits: ["Fortalecimento do core", "Melhoria da postura", "Aumento da flexibilidade", "Prevenção de lesões"],
      duration: "60 min",
      intensity: "Média",
    },
    {
      id: "yoga-flow",
      title: "Yoga Flow",
      description: "Movimento fluido em sintonia com a respiração. Uma prática dinâmica que conecta posturas numa sequência contínua, promovendo força, flexibilidade e clareza mental.",
      image: "/images/modality-yoga-flow.jpg",
      benefits: ["Aumento da flexibilidade", "Fortalecimento muscular", "Redução do stress", "Melhoria do foco"],
      duration: "60 min",
      intensity: "Média",
    },
    {
      id: "yoga-restore",
      title: "Yoga Restore",
      description: "Relaxamento profundo e recuperação. Uma prática suave e terapêutica que utiliza apoios para permitir que o corpo se relaxe profundamente em cada postura.",
      image: "/images/modality-yoga-restore.jpg",
      benefits: ["Relaxamento profundo", "Redução da ansiedade", "Melhoria do sono", "Recuperação muscular"],
      duration: "75 min",
      intensity: "Suave",
    },
    {
      id: "barre",
      title: "Barre",
      description: "Fusão de ballet, pilates e yoga. Um treino de baixo impacto mas de alta intensidade que cria um corpo longo e elegante, focado no fortalecimento e tonificação.",
      image: "/images/modality-barre.jpg",
      benefits: ["Tonificação muscular", "Melhoria da postura", "Aumento da flexibilidade", "Coordenação e equilíbrio"],
      duration: "60 min",
      intensity: "Alta",
    },
  ],
};

// ============================================================================
// Transformation Section Configuration
// ============================================================================

export interface TransformationConfig {
  title: string;
  description: string;
  ctaText: string;
  backgroundImage: string;
}

export const transformationConfig: TransformationConfig = {
  title: "Transforme o Seu Corpo e a Sua Mente",
  description: "Cada aula é uma oportunidade de evolução. Com instrutores certificados e uma metodologia única, a pilatGZ acompanha a sua jornada de transformação pessoal, respeitando o seu ritmo e as suas necessidades.",
  ctaText: "Comece a Sua Jornada",
  backgroundImage: "/images/transformation-bg.jpg",
};

// ============================================================================
// Testimonials Section Configuration
// ============================================================================

export interface TestimonialItem {
  id: number;
  name: string;
  title: string;
  quote: string;
  image: string;
}

export interface TestimonialsConfig {
  tag: string;
  title: string;
  testimonials: TestimonialItem[];
}

export const testimonialsConfig: TestimonialsConfig = {
  tag: "TESTEMUNHOS",
  title: "O Que Dizem os Nossos Alunos",
  testimonials: [
    {
      id: 1,
      name: "Ana Silva",
      title: "Aluna de Pilates",
      quote: "A pilatGZ transformou a minha relação com o exercício. Sinto-me mais forte, flexível e em paz. Os instrutores são atenciosos e o ambiente é acolhedor.",
      image: "/images/testimonial-1.jpg",
    },
    {
      id: 2,
      name: "Maria Santos",
      title: "Aluna de Yoga",
      quote: "O ambiente é acolhedor e os instrutores são incríveis. Cada aula é um momento de conexão comigo mesma. Recomendo a todas as pessoas que procuram bem-estar.",
      image: "/images/testimonial-2.jpg",
    },
    {
      id: 3,
      name: "Carolina Mendes",
      title: "Aluna de Barre",
      quote: "Finalmente encontrei um espaço onde me sinto em casa. O Barre mudou a minha postura e a minha confiança. As aulas são desafiantes mas acessíveis.",
      image: "/images/testimonial-3.jpg",
    },
  ],
};

// ============================================================================
// Quote Section Configuration
// ============================================================================

export interface QuoteConfig {
  quote: string;
  attribution: string;
}

export const quoteConfig: QuoteConfig = {
  quote: "O movimento é a música do corpo em silêncio.",
  attribution: "— Fundadora, pilatGZ",
};

// ============================================================================
// FAQ Section Configuration
// ============================================================================

export interface FAQItem {
  question: string;
  answer: string;
}

export interface FAQConfig {
  title: string;
  faqs: FAQItem[];
}

export const faqConfig: FAQConfig = {
  title: "Perguntas Frequentes",
  faqs: [
    {
      question: "Preciso de experiência prévia?",
      answer: "Não! As nossas aulas são adequadas para todos os níveis, desde iniciantes até praticantes avançados. Os nossos instrutores adaptam os exercícios às necessidades de cada aluno.",
    },
    {
      question: "O que devo trazer?",
      answer: "Apenas roupa confortável e uma garrafa de água. Fornecemos todos os equipamentos necessários, incluindo tapetes, blocos e apoios.",
    },
    {
      question: "Qual é a duração das aulas?",
      answer: "As aulas têm duração de 50 a 75 minutos, dependendo da modalidade. O Yoga Restore é mais longo (75 min) para permitir um relaxamento profundo.",
    },
    {
      question: "Posso fazer uma aula experimental?",
      answer: "Sim! Oferecemos uma aula experimental para que possa conhecer o nosso espaço e metodologia. É a melhor forma de descobrir se a pilatGZ é para si.",
    },
    {
      question: "Como faço para reservar?",
      answer: "Pode reservar diretamente através do nosso site na secção de Reservas, ou contactar-nos por telefone ou email. Recomendamos reservar com antecedência.",
    },
    {
      question: "Qual é a política de cancelamento?",
      answer: "Pedimos que cancele com pelo menos 24 horas de antecedência. Cancelamentos com menos de 24 horas podem ser sujeitos a taxa.",
    },
  ],
};

// ============================================================================
// Pricing Section Configuration
// ============================================================================

export interface PricingPlan {
  id: number;
  name: string;
  price: number;
  unit: string;
  featured: boolean;
  features: string[];
}

export interface PricingConfig {
  title: string;
  subtitle: string;
  ctaButtonText: string;
  plans: PricingPlan[];
}

export const pricingConfig: PricingConfig = {
  title: "Planos e Preços",
  subtitle: "Escolha o plano que melhor se adapta às suas necessidades. Todos os planos incluem acesso às nossas instalações.",
  ctaButtonText: "Escolher Plano",
  plans: [
    {
      id: 1,
      name: "Aula Avulsa",
      price: 15,
      unit: "por aula",
      featured: false,
      features: ["Uma aula à sua escolha", "Válido por 30 dias", "Acesso a todas as modalidades", "Equipamento incluído"],
    },
    {
      id: 2,
      name: "Pack 5 Aulas",
      price: 65,
      unit: "válido 3 meses",
      featured: true,
      features: ["5 aulas à sua escolha", "Válido por 3 meses", "Acesso a todas as modalidades", "Economize €10"],
    },
    {
      id: 3,
      name: "Pack 10 Aulas",
      price: 120,
      unit: "válido 3 meses",
      featured: false,
      features: ["10 aulas à sua escolha", "Válido por 3 meses", "Acesso a todas as modalidades", "Economize €30"],
    },
    {
      id: 4,
      name: "Mensalidade",
      price: 85,
      unit: "por mês",
      featured: false,
      features: ["Aulas ilimitadas", "Acesso a todas as modalidades", "Cancelamento mensal", "Melhor valor"],
    },
  ],
};

// ============================================================================
// Blog Section Configuration
// ============================================================================

export interface BlogPost {
  id: number;
  title: string;
  excerpt: string;
  readTime: string;
  date: string;
  image: string;
  category: string;
}

export interface BlogConfig {
  title: string;
  subtitle: string;
  allPostsLabel: string;
  readMoreLabel: string;
  readTimePrefix: string;
  posts: BlogPost[];
}

export const blogConfig: BlogConfig = {
  title: "Inspiração & Bem-Estar",
  subtitle: "Dicas, insights e histórias para enriquecer a sua prática e o seu dia a dia.",
  allPostsLabel: "Ver Todos",
  readMoreLabel: "Ler Mais",
  readTimePrefix: "Leitura: ",
  posts: [
    {
      id: 1,
      title: "5 Benefícios do Pilates para a Postura",
      excerpt: "Descubra como o Pilates pode transformar a sua postura, aliviar dores nas costas e melhorar o seu bem-estar geral.",
      readTime: "5 min",
      date: "15 Fev, 2024",
      image: "/images/blog-1.jpg",
      category: "Pilates",
    },
    {
      id: 2,
      title: "A Respiração Consciente no Yoga",
      excerpt: "Aprenda técnicas de respiração que vão acalmar a sua mente, reduzir o stress e energizar o seu corpo.",
      readTime: "4 min",
      date: "10 Fev, 2024",
      image: "/images/blog-2.jpg",
      category: "Yoga",
    },
    {
      id: 3,
      title: "Criar uma Rotina de Bem-Estar",
      excerpt: "Dicas práticas para integrar o movimento e a mindfulness no seu dia a dia, mesmo com uma agenda ocupada.",
      readTime: "6 min",
      date: "5 Fev, 2024",
      image: "/images/blog-3.jpg",
      category: "Bem-Estar",
    },
  ],
};

// ============================================================================
// Contact Section Configuration
// ============================================================================

export interface ContactFormOption {
  value: string;
  label: string;
}

export interface ContactConfig {
  title: string;
  subtitle: string;
  nameLabel: string;
  emailLabel: string;
  phoneLabel: string;
  projectTypeLabel: string;
  projectTypePlaceholder: string;
  projectTypeOptions: ContactFormOption[];
  messageLabel: string;
  submitButtonText: string;
  image: string;
  address: string;
  phone: string;
  email: string;
  hours: string;
}

export const contactConfig: ContactConfig = {
  title: "Entre em Contacto",
  subtitle: "Estamos aqui para ajudar. Envie-nos uma mensagem ou visite-nos no nosso espaço em Aveiro.",
  nameLabel: "Nome *",
  emailLabel: "Email *",
  phoneLabel: "Telefone",
  projectTypeLabel: "Assunto",
  projectTypePlaceholder: "Selecione...",
  projectTypeOptions: [
    { value: "aula", label: "Aula Experimental" },
    { value: "info", label: "Informações" },
    { value: "planos", label: "Planos e Preços" },
    { value: "outro", label: "Outro" },
  ],
  messageLabel: "Mensagem",
  submitButtonText: "Enviar Mensagem",
  image: "/images/cta-image.jpg",
  address: "Rua dos Combatentes da Liberdade, 45, Aveiro",
  phone: "+351 234 567 890",
  email: "info@pilatgz.pt",
  hours: "Seg - Sex: 7h - 21h | Sáb: 9h - 13h",
};

// ============================================================================
// CTA Section Configuration
// ============================================================================

export interface CTAConfig {
  title: string;
  subtitle: string;
  primaryCta: string;
  secondaryCta: string;
  image: string;
}

export const ctaConfig: CTAConfig = {
  title: "Comece a Sua Jornada Hoje",
  subtitle: "Agende a sua primeira aula e descubra o poder da pilatGZ. O primeiro passo para uma vida mais equilibrada começa aqui.",
  primaryCta: "Agendar Aula",
  secondaryCta: "Contacte-nos",
  image: "/images/cta-image.jpg",
};

// ============================================================================
// Footer Configuration
// ============================================================================

export interface FooterLink {
  label: string;
  href: string;
  icon?: string;
}

export interface FooterConfig {
  marqueeText: string;
  marqueeHighlightChars: string[];
  navLinks1: FooterLink[];
  navLinks2: FooterLink[];
  ctaText: string;
  ctaHref: string;
  copyright: string;
  tagline: string;
}

export const footerConfig: FooterConfig = {
  marqueeText: "Celebre o Movimento • Alimente o Seu Mood • Cuide de Si • ",
  marqueeHighlightChars: ["M", "S"],
  navLinks1: [
    { label: "Home", href: "#hero" },
    { label: "Sobre", href: "#about" },
    { label: "Modalidades", href: "#modalities" },
    { label: "Reservas", href: "#reservas" },
    { label: "Contactos", href: "#contact" },
  ],
  navLinks2: [
    { label: "Pilates Mat", href: "#modalities" },
    { label: "Yoga Flow", href: "#modalities" },
    { label: "Yoga Restore", href: "#modalities" },
    { label: "Barre", href: "#modalities" },
  ],
  ctaText: "Agendar Aula",
  ctaHref: "#reservas",
  copyright: "© 2024 pilatGZ. Todos os direitos reservados.",
  tagline: "Transforme o seu corpo e a sua mente",
};

// ============================================================================
// Instructors Section Configuration
// ============================================================================

export interface InstructorItem {
  id: number;
  name: string;
  role: string;
  bio: string;
  specialties: string[];
  image: string;
}

export interface InstructorsConfig {
  tag: string;
  title: string;
  subtitle: string;
  instructors: InstructorItem[];
}

export const instructorsConfig: InstructorsConfig = {
  tag: "EQUIPA",
  title: "Conheça os Nossos Instrutores",
  subtitle: "Uma equipa dedicada de profissionais certificados, prontos para acompanhar a sua jornada de bem-estar.",
  instructors: [
    {
      id: 1,
      name: "Gabriela Ferreira",
      role: "Fundadora & Instrutora Principal",
      bio: "Certificada em Pilates Clássico e Yoga Hatha, com mais de 15 anos de experiência. A sua abordagem combina técnica precisa com atenção individualizada.",
      specialties: ["Pilates Mat", "Pilates Reformer", "Yoga Hatha"],
      image: "/images/instructor-1.jpg",
    },
    {
      id: 2,
      name: "Sofia Martins",
      role: "Instrutora de Yoga",
      bio: "Especialista em Yoga Flow e Restore, formada na Índia. Acredita que o yoga é para todos os corpos e todos os níveis de experiência.",
      specialties: ["Yoga Flow", "Yoga Restore", "Meditação"],
      image: "/images/instructor-2.jpg",
    },
  ],
};
