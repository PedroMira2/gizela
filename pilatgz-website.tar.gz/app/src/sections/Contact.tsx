import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Send, MapPin, Phone, Mail, Clock } from 'lucide-react';
import { contactConfig } from '../config';

gsap.registerPlugin(ScrollTrigger);

export function Contact() {
  const sectionRef = useRef<HTMLElement>(null);
  const formRef = useRef<HTMLFormElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const infoRef = useRef<HTMLDivElement>(null);
  const triggersRef = useRef<ScrollTrigger[]>([]);

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
  });

  if (!contactConfig.title) return null;

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const trigger = ScrollTrigger.create({
      trigger: section,
      start: 'top 80%',
      onEnter: () => {
        const tl = gsap.timeline();

        // Title fade
        tl.fromTo(
          titleRef.current,
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, ease: 'power2.out' }
        );

        // Subtitle
        tl.fromTo(
          subtitleRef.current,
          { y: 20, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.5, ease: 'power2.out' },
          '-=0.4'
        );

        // Form
        tl.fromTo(
          formRef.current,
          { x: -40, opacity: 0 },
          { x: 0, opacity: 1, duration: 0.7, ease: 'power2.out' },
          '-=0.3'
        );

        // Image
        tl.fromTo(
          imageRef.current,
          { clipPath: 'polygon(100% 0, 100% 0, 100% 100%, 100% 100%)' },
          {
            clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0 100%)',
            duration: 1,
            ease: 'expo.out',
          },
          '-=0.5'
        );

        // Info
        tl.fromTo(
          infoRef.current,
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.6, ease: 'power2.out' },
          '-=0.5'
        );
      },
      once: true,
    });
    triggersRef.current.push(trigger);

    return () => {
      triggersRef.current.forEach((t) => t.kill());
      triggersRef.current = [];
    };
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    alert('Mensagem enviada com sucesso! Entraremos em contacto em breve.');
    setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
  };

  return (
    <section
      ref={sectionRef}
      id="contact"
      className="relative py-24 md:py-32 px-8 lg:px-16 bg-[var(--pilat-beige)]"
    >
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h2
            ref={titleRef}
            className="text-3xl md:text-4xl lg:text-5xl text-[var(--pilat-dark)] font-normal mb-4"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            {contactConfig.title}
          </h2>
          <p ref={subtitleRef} className="text-base md:text-lg text-[var(--pilat-gray)] max-w-2xl mx-auto">
            {contactConfig.subtitle}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16">
          {/* Form */}
          <form
            ref={formRef}
            onSubmit={handleSubmit}
            className="space-y-6"
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm text-[var(--pilat-gray)] mb-2">
                  {contactConfig.nameLabel}
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-3 bg-[var(--pilat-cream)] border border-[var(--pilat-sand)] rounded-lg text-[var(--pilat-dark)] focus:outline-none focus:border-[var(--pilat-taupe)] transition-colors"
                  required
                />
              </div>
              <div>
                <label className="block text-sm text-[var(--pilat-gray)] mb-2">
                  {contactConfig.emailLabel}
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-4 py-3 bg-[var(--pilat-cream)] border border-[var(--pilat-sand)] rounded-lg text-[var(--pilat-dark)] focus:outline-none focus:border-[var(--pilat-taupe)] transition-colors"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm text-[var(--pilat-gray)] mb-2">
                  {contactConfig.phoneLabel}
                </label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full px-4 py-3 bg-[var(--pilat-cream)] border border-[var(--pilat-sand)] rounded-lg text-[var(--pilat-dark)] focus:outline-none focus:border-[var(--pilat-taupe)] transition-colors"
                />
              </div>
              <div>
                <label className="block text-sm text-[var(--pilat-gray)] mb-2">
                  {contactConfig.projectTypeLabel}
                </label>
                <select
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  className="w-full px-4 py-3 bg-[var(--pilat-cream)] border border-[var(--pilat-sand)] rounded-lg text-[var(--pilat-dark)] focus:outline-none focus:border-[var(--pilat-taupe)] transition-colors"
                >
                  <option value="">{contactConfig.projectTypePlaceholder}</option>
                  {contactConfig.projectTypeOptions.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm text-[var(--pilat-gray)] mb-2">
                {contactConfig.messageLabel}
              </label>
              <textarea
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                rows={5}
                className="w-full px-4 py-3 bg-[var(--pilat-cream)] border border-[var(--pilat-sand)] rounded-lg text-[var(--pilat-dark)] focus:outline-none focus:border-[var(--pilat-taupe)] transition-colors resize-none"
              />
            </div>

            <button
              type="submit"
              className="btn-primary w-full sm:w-auto"
            >
              {contactConfig.submitButtonText}
              <Send className="w-4 h-4 ml-2" />
            </button>
          </form>

          {/* Image & Info */}
          <div className="space-y-8">
            <div
              ref={imageRef}
              className="relative aspect-[4/3] overflow-hidden rounded-2xl"
            >
              <img
                src={contactConfig.image}
                alt="Contact"
                className="w-full h-full object-cover"
              />
            </div>

            <div ref={infoRef} className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-[var(--pilat-taupe)] mt-0.5" />
                <div>
                  <h4 className="text-sm font-medium text-[var(--pilat-dark)] mb-1">Morada</h4>
                  <p className="text-sm text-[var(--pilat-gray)]">{contactConfig.address}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-[var(--pilat-taupe)] mt-0.5" />
                <div>
                  <h4 className="text-sm font-medium text-[var(--pilat-dark)] mb-1">Telefone</h4>
                  <p className="text-sm text-[var(--pilat-gray)]">{contactConfig.phone}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-[var(--pilat-taupe)] mt-0.5" />
                <div>
                  <h4 className="text-sm font-medium text-[var(--pilat-dark)] mb-1">Email</h4>
                  <p className="text-sm text-[var(--pilat-gray)]">{contactConfig.email}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Clock className="w-5 h-5 text-[var(--pilat-taupe)] mt-0.5" />
                <div>
                  <h4 className="text-sm font-medium text-[var(--pilat-dark)] mb-1">Horário</h4>
                  <p className="text-sm text-[var(--pilat-gray)]">{contactConfig.hours}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
