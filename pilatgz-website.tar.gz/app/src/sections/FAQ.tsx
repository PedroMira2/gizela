import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Plus } from 'lucide-react';
import { faqConfig } from '../config';

gsap.registerPlugin(ScrollTrigger);

export function FAQ() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const itemsRef = useRef<(HTMLDivElement | null)[]>([]);
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const triggersRef = useRef<ScrollTrigger[]>([]);

  if (!faqConfig.title || faqConfig.faqs.length === 0) return null;

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const trigger = ScrollTrigger.create({
      trigger: section,
      start: 'top 80%',
      onEnter: () => {
        const tl = gsap.timeline();

        // Title fade in
        tl.fromTo(
          titleRef.current,
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, ease: 'power2.out' }
        );

        // FAQ items stagger
        itemsRef.current.forEach((item, i) => {
          if (item) {
            const fromX = i % 2 === 0 ? -40 : 40;
            tl.fromTo(
              item,
              { x: fromX, opacity: 0 },
              { x: 0, opacity: 1, duration: 0.5, ease: 'power2.out' },
              `-=0.4`
            );
          }
        });
      },
      once: true,
    });
    triggersRef.current.push(trigger);

    return () => {
      triggersRef.current.forEach((t) => t.kill());
      triggersRef.current = [];
    };
  }, []);

  const toggleItem = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section
      ref={sectionRef}
      id="faq"
      className="relative py-24 md:py-32 px-8 lg:px-16 bg-[var(--pilat-cream)]"
    >
      <div className="max-w-4xl mx-auto">
        {/* Section title */}
        <h2
          ref={titleRef}
          className="text-3xl md:text-4xl lg:text-5xl text-[var(--pilat-dark)] font-normal text-center mb-16"
          style={{ fontFamily: "'Playfair Display', serif" }}
        >
          {faqConfig.title}
        </h2>

        {/* FAQ items */}
        <div className="space-y-0">
          {faqConfig.faqs.map((faq, index) => (
            <div
              key={index}
              ref={(el) => {
                itemsRef.current[index] = el;
              }}
              className={`relative ${
                index % 2 === 0 ? 'lg:-translate-x-4' : 'lg:translate-x-4'
              }`}
            >
              {/* Question */}
              <button
                className={`w-full py-5 lg:py-6 flex items-center justify-between text-left border-b transition-all duration-300 ${
                  openIndex === index
                    ? 'border-[var(--pilat-taupe)]'
                    : 'border-[var(--pilat-sand)] hover:border-[var(--pilat-taupe)]'
                }`}
                onClick={() => toggleItem(index)}
              >
                <h3
                  className={`text-base lg:text-lg text-[var(--pilat-dark)] pr-8 transition-all duration-200 ${
                    openIndex === index ? 'font-medium' : 'font-normal'
                  }`}
                >
                  {faq.question}
                </h3>

                {/* Plus icon */}
                <div
                  className={`flex-shrink-0 w-8 h-8 rounded-full border border-[var(--pilat-taupe)] flex items-center justify-center transition-all duration-300 ${
                    openIndex === index
                      ? 'bg-[var(--pilat-taupe)] rotate-45'
                      : 'hover:border-[var(--pilat-dark)]'
                  }`}
                >
                  <Plus className={`w-4 h-4 ${openIndex === index ? 'text-white' : 'text-[var(--pilat-dark)]'}`} />
                </div>
              </button>

              {/* Answer */}
              <div
                className={`overflow-hidden transition-all duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] ${
                  openIndex === index
                    ? 'max-h-[500px] opacity-100'
                    : 'max-h-0 opacity-0'
                }`}
              >
                <div className="py-5 lg:py-6">
                  <p className="text-sm lg:text-base text-[var(--pilat-gray)] leading-relaxed">
                    {faq.answer}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
