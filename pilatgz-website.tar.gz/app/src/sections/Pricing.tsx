import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Check } from 'lucide-react';
import { pricingConfig } from '../config';

gsap.registerPlugin(ScrollTrigger);

export function Pricing() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);
  const [animatedPrices, setAnimatedPrices] = useState<number[]>([]);
  const triggersRef = useRef<ScrollTrigger[]>([]);

  if (!pricingConfig.title || pricingConfig.plans.length === 0) return null;

  const plans = pricingConfig.plans;

  useEffect(() => {
    setAnimatedPrices(new Array(plans.length).fill(0));

    const section = sectionRef.current;
    if (!section) return;

    const trigger = ScrollTrigger.create({
      trigger: section,
      start: 'top 80%',
      onEnter: () => {
        const tl = gsap.timeline();

        // Title fade up
        tl.fromTo(
          titleRef.current,
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, ease: 'power2.out' }
        );

        // Subtitle
        tl.fromTo(
          subtitleRef.current,
          { y: 20, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.5, ease: 'power2.out' },
          '-=0.4'
        );

        // Cards entry
        cardsRef.current.forEach((card, i) => {
          if (card) {
            tl.fromTo(
              card,
              { y: 60, opacity: 0 },
              {
                y: 0,
                opacity: 1,
                duration: 0.6,
                ease: 'back.out(1.2)',
              },
              `-=${0.5 - i * 0.1}`
            );

            // Features stagger
            const features = card.querySelectorAll('.feature-item');
            tl.fromTo(
              features,
              { x: -10, opacity: 0 },
              {
                x: 0,
                opacity: 1,
                duration: 0.4,
                stagger: 0.05,
                ease: 'power2.out',
              },
              '-=0.4'
            );
          }
        });

        // Animate price counters
        plans.forEach((plan, i) => {
          const obj = { value: 0 };
          gsap.to(obj, {
            value: plan.price,
            duration: 1.2,
            delay: 0.5,
            ease: 'power2.out',
            onUpdate: () => {
              setAnimatedPrices((prev) => {
                const newPrices = [...prev];
                newPrices[i] = Math.round(obj.value);
                return newPrices;
              });
            },
          });
        });
      },
      once: true,
    });
    triggersRef.current.push(trigger);

    return () => {
      triggersRef.current.forEach((t) => t.kill());
      triggersRef.current = [];
    };
  }, []);

  const handleCardHover = (index: number, isEntering: boolean) => {
    const card = cardsRef.current[index];
    if (!card) return;

    if (isEntering) {
      gsap.to(card, {
        y: -10,
        boxShadow: '0 25px 50px rgba(14, 13, 13, 0.12)',
        duration: 0.4,
        ease: 'power2.out',
      });
    } else {
      gsap.to(card, {
        y: 0,
        boxShadow: '0 10px 30px rgba(14, 13, 13, 0.06)',
        duration: 0.4,
        ease: 'power2.out',
      });
    }
  };

  return (
    <section
      ref={sectionRef}
      id="pricing"
      className="relative py-24 md:py-32 px-8 lg:px-16 bg-[var(--pilat-beige)]"
    >
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h2
            ref={titleRef}
            className="text-3xl md:text-4xl lg:text-5xl text-[var(--pilat-dark)] font-normal mb-4"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            {pricingConfig.title}
          </h2>
          <p ref={subtitleRef} className="text-base md:text-lg text-[var(--pilat-gray)]">
            {pricingConfig.subtitle}
          </p>
        </div>

        {/* Pricing cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-stretch">
          {plans.map((plan, index) => (
            <div
              key={plan.id}
              ref={(el) => {
                cardsRef.current[index] = el;
              }}
              className={`relative p-6 lg:p-8 rounded-2xl transition-all duration-300 ${
                plan.featured
                  ? 'bg-[var(--pilat-dark)] text-white'
                  : 'bg-[var(--pilat-cream)] text-[var(--pilat-dark)] hover:shadow-lg'
              }`}
              style={{
                willChange: 'transform, box-shadow',
              }}
              onMouseEnter={() => handleCardHover(index, true)}
              onMouseLeave={() => handleCardHover(index, false)}
            >
              {/* Featured badge */}
              {plan.featured && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-[var(--pilat-taupe)] text-white text-xs rounded-full">
                  Mais Popular
                </div>
              )}

              {/* Plan name */}
              <h3
                className={`text-lg mb-4 ${
                  plan.featured ? 'text-white/80' : 'text-[var(--pilat-gray)]'
                }`}
              >
                {plan.name}
              </h3>

              {/* Price */}
              <div className="mb-6">
                <span className="text-3xl lg:text-4xl font-medium tabular-nums">
                  €{(animatedPrices[index] || 0).toLocaleString()}
                </span>
                <span
                  className={`text-sm ml-1 ${
                    plan.featured ? 'text-white/60' : 'text-[var(--pilat-gray)]'
                  }`}
                >
                  / {plan.unit}
                </span>
              </div>

              {/* Features */}
              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, i) => (
                  <li
                    key={i}
                    className={`feature-item flex items-center gap-3 text-sm ${
                      plan.featured ? 'text-white/70' : 'text-[var(--pilat-gray)]'
                    }`}
                  >
                    <Check
                      className={`w-4 h-4 flex-shrink-0 ${
                        plan.featured ? 'text-[var(--pilat-taupe)]' : 'text-[var(--pilat-taupe)]'
                      }`}
                    />
                    {feature}
                  </li>
                ))}
              </ul>

              {/* CTA Button */}
              <button
                className={`w-full py-3 text-sm font-medium rounded-full transition-all duration-200 ${
                  plan.featured
                    ? 'bg-white text-[var(--pilat-dark)] hover:bg-[var(--pilat-taupe)] hover:text-white'
                    : 'border border-[var(--pilat-dark)] text-[var(--pilat-dark)] hover:bg-[var(--pilat-dark)] hover:text-white'
                }`}
              >
                {pricingConfig.ctaButtonText}
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
