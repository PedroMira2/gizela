import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Instagram, Facebook, ArrowUpRight } from 'lucide-react';
import { footerConfig } from '../config';

gsap.registerPlugin(ScrollTrigger);

export function Footer() {
  const sectionRef = useRef<HTMLElement>(null);
  const marqueeRef = useRef<HTMLDivElement>(null);
  const linksCol1Ref = useRef<(HTMLAnchorElement | null)[]>([]);
  const linksCol2Ref = useRef<(HTMLAnchorElement | null)[]>([]);
  const copyrightRef = useRef<HTMLDivElement>(null);
  const triggersRef = useRef<ScrollTrigger[]>([]);

  if (!footerConfig.copyright) return null;

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const trigger = ScrollTrigger.create({
      trigger: section,
      start: 'top 90%',
      onEnter: () => {
        const tl = gsap.timeline();

        // Marquee fade in
        tl.fromTo(
          marqueeRef.current,
          { opacity: 0 },
          { opacity: 1, duration: 1, ease: 'power2.out' }
        );

        // Links column 1 stagger
        linksCol1Ref.current.forEach((link, i) => {
          if (link) {
            tl.fromTo(
              link,
              { y: 20, opacity: 0 },
              { y: 0, opacity: 1, duration: 0.4, ease: 'power2.out' },
              `-=${0.3 - i * 0.05}`
            );
          }
        });

        // Links column 2 stagger
        linksCol2Ref.current.forEach((link, i) => {
          if (link) {
            tl.fromTo(
              link,
              { y: 20, opacity: 0 },
              { y: 0, opacity: 1, duration: 0.4, ease: 'power2.out' },
              `-=${0.3 - i * 0.05}`
            );
          }
        });

        // Copyright fade up
        tl.fromTo(
          copyrightRef.current,
          { y: 20, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.5, ease: 'power2.out' },
          '-=0.2'
        );
      },
      once: true,
    });
    triggersRef.current.push(trigger);

    return () => {
      triggersRef.current.forEach((t) => t.kill());
      triggersRef.current = [];
    };
  }, []);

  const marqueeText = footerConfig.marqueeText;

  return (
    <footer
      ref={sectionRef}
      className="relative pt-16 pb-8 px-8 lg:px-16 bg-[var(--pilat-dark)] overflow-hidden"
    >
      {/* Marquee section */}
      <div
        ref={marqueeRef}
        className="relative mb-16 overflow-hidden"
      >
        {/* Gradient masks */}
        <div className="absolute left-0 top-0 bottom-0 w-40 bg-gradient-to-r from-[var(--pilat-dark)] to-transparent z-10" />
        <div className="absolute right-0 top-0 bottom-0 w-40 bg-gradient-to-l from-[var(--pilat-dark)] to-transparent z-10" />

        {/* Marquee content */}
        <div className="marquee-container">
          <div className="marquee-content flex items-center gap-8 text-4xl md:text-6xl lg:text-7xl font-normal whitespace-nowrap text-white/10">
            {[...Array(4)].map((_, i) => (
              <span key={i} className="flex items-center gap-8">
                {marqueeText}
                <span className="mx-4">&bull;</span>
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Footer content */}
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12 mb-12">
          {/* Column 1 - Logo & Tagline */}
          <div className="col-span-2 lg:col-span-1">
            <h3 className="text-2xl text-white font-normal mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
              pilatGZ
            </h3>
            <p className="text-sm text-white/50">{footerConfig.tagline}</p>
          </div>

          {/* Column 2 - Nav links */}
          <div className="space-y-3">
            <h4 className="text-xs uppercase tracking-wider text-white/40 mb-4">Navegação</h4>
            {footerConfig.navLinks1.map((link, i) => (
              <a
                key={link.label}
                ref={(el) => {
                  linksCol1Ref.current[i] = el;
                }}
                href={link.href}
                className="block text-sm text-white/60 hover:text-white transition-colors duration-300"
              >
                {link.label}
              </a>
            ))}
          </div>

          {/* Column 3 - Modalities */}
          <div className="space-y-3">
            <h4 className="text-xs uppercase tracking-wider text-white/40 mb-4">Modalidades</h4>
            {footerConfig.navLinks2.map((link, i) => (
              <a
                key={link.label}
                ref={(el) => {
                  linksCol2Ref.current[i] = el;
                }}
                href={link.href}
                className="block text-sm text-white/60 hover:text-white transition-colors duration-300"
              >
                {link.label}
              </a>
            ))}
          </div>

          {/* Column 4 - CTA & Social */}
          <div className="col-span-2 lg:col-span-1">
            <a
              href={footerConfig.ctaHref}
              className="inline-flex items-center gap-2 text-white hover:text-[var(--pilat-taupe)] transition-colors duration-300 mb-6"
            >
              {footerConfig.ctaText}
              <ArrowUpRight className="w-4 h-4" />
            </a>
            <div className="flex items-center gap-4">
              <a
                href="#"
                className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center text-white/60 hover:text-white hover:border-white transition-all duration-300"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="#"
                className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center text-white/60 hover:text-white hover:border-white transition-all duration-300"
              >
                <Facebook className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div
          ref={copyrightRef}
          className="pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4"
        >
          <p className="text-xs text-white/40">
            {footerConfig.copyright}
          </p>
          <p className="text-xs text-white/30">
            Aveiro, Portugal
          </p>
        </div>
      </div>
    </footer>
  );
}
