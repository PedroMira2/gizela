import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { transformationConfig } from '../config';

gsap.registerPlugin(ScrollTrigger);

export function Transformation() {
  const sectionRef = useRef<HTMLElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const triggersRef = useRef<ScrollTrigger[]>([]);

  if (!transformationConfig.title) return null;

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    // Parallax effect on background
    const parallaxTrigger = ScrollTrigger.create({
      trigger: section,
      start: 'top bottom',
      end: 'bottom top',
      scrub: 1,
      onUpdate: (self) => {
        if (imageRef.current) {
          gsap.set(imageRef.current, {
            y: -80 * self.progress,
            scale: 1 + self.progress * 0.1,
          });
        }
      },
    });
    triggersRef.current.push(parallaxTrigger);

    // Content reveal
    const contentTrigger = ScrollTrigger.create({
      trigger: contentRef.current,
      start: 'top 75%',
      onEnter: () => {
        gsap.fromTo(
          contentRef.current,
          { y: 50, opacity: 0 },
          { y: 0, opacity: 1, duration: 1, ease: 'power2.out' }
        );
      },
      once: true,
    });
    triggersRef.current.push(contentTrigger);

    return () => {
      triggersRef.current.forEach((t) => t.kill());
      triggersRef.current = [];
    };
  }, []);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      className="relative min-h-[80vh] flex items-center justify-center overflow-hidden"
    >
      {/* Background image */}
      <div
        ref={imageRef}
        className="absolute inset-0 z-0"
        style={{ willChange: 'transform' }}
      >
        <img
          src={transformationConfig.backgroundImage}
          alt="Transformação"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-[var(--pilat-dark)]/50" />
      </div>

      {/* Content */}
      <div
        ref={contentRef}
        className="relative z-10 max-w-3xl mx-auto px-8 text-center"
      >
        <div className="glass rounded-3xl p-8 md:p-12 lg:p-16">
          <h2
            className="text-3xl md:text-4xl lg:text-5xl text-[var(--pilat-dark)] font-normal mb-6"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            {transformationConfig.title}
          </h2>
          <p className="text-base md:text-lg text-[var(--pilat-gray)] mb-8 leading-relaxed">
            {transformationConfig.description}
          </p>
          <a
            href="#contact"
            onClick={(e) => handleNavClick(e, '#contact')}
            className="btn-primary"
          >
            {transformationConfig.ctaText}
          </a>
        </div>
      </div>
    </section>
  );
}
