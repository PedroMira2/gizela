import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { aboutConfig } from '../config';

gsap.registerPlugin(ScrollTrigger);

export function About() {
  const sectionRef = useRef<HTMLElement>(null);
  const image1Ref = useRef<HTMLDivElement>(null);
  const image2Ref = useRef<HTMLDivElement>(null);
  const authorImageRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const textRef = useRef<HTMLParagraphElement>(null);
  const lineRef = useRef<HTMLDivElement>(null);
  const authorTextRef = useRef<HTMLDivElement>(null);
  const triggersRef = useRef<ScrollTrigger[]>([]);

  if (!aboutConfig.titleLine1) return null;

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    // Entry animations
    const trigger = ScrollTrigger.create({
      trigger: section,
      start: 'top 80%',
      onEnter: () => {
        const tl = gsap.timeline();

        // Image 1 clip reveal
        tl.fromTo(
          image1Ref.current,
          { clipPath: 'inset(100% 0 0 0)', scale: 1.1 },
          {
            clipPath: 'inset(0% 0 0 0)',
            scale: 1,
            duration: 1.2,
            ease: 'expo.out',
          }
        );

        // Image 2 clip reveal
        tl.fromTo(
          image2Ref.current,
          { clipPath: 'inset(0 100% 0 0)', scale: 1.05 },
          {
            clipPath: 'inset(0 0% 0 0)',
            scale: 1,
            duration: 1.1,
            ease: 'expo.out',
          },
          '-=0.9'
        );

        // Title lines reveal
        if (titleRef.current) {
          const lines = titleRef.current.querySelectorAll('.title-line');
          tl.fromTo(
            lines,
            { y: 40, opacity: 0 },
            {
              y: 0,
              opacity: 1,
              duration: 0.8,
              stagger: 0.2,
              ease: 'back.out(1.4)',
            },
            '-=0.8'
          );
        }

        // Text fade up
        tl.fromTo(
          textRef.current,
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, ease: 'power2.out' },
          '-=0.4'
        );

        // Accent line
        tl.fromTo(
          lineRef.current,
          { width: 0 },
          { width: '80px', duration: 1, ease: 'expo.inOut' },
          '-=0.6'
        );

        // Author image
        tl.fromTo(
          authorImageRef.current,
          { scale: 0.9, opacity: 0 },
          {
            scale: 1,
            opacity: 1,
            duration: 0.9,
            ease: 'elastic.out(1, 0.5)',
          },
          '-=0.7'
        );

        // Author text
        tl.fromTo(
          authorTextRef.current,
          { y: 15, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.6, ease: 'power2.out' },
          '-=0.5'
        );
      },
      once: true,
    });
    triggersRef.current.push(trigger);

    // Parallax on scroll
    const parallaxTrigger = ScrollTrigger.create({
      trigger: section,
      start: 'top bottom',
      end: 'bottom top',
      scrub: 1,
      onUpdate: (self) => {
        if (image1Ref.current) {
          gsap.set(image1Ref.current, {
            y: 50 - self.progress * 100,
          });
        }
        if (image2Ref.current) {
          gsap.set(image2Ref.current, {
            y: -30 + self.progress * 60,
          });
        }
        if (authorImageRef.current) {
          gsap.set(authorImageRef.current, {
            y: 30 - self.progress * 60,
          });
        }
      },
    });
    triggersRef.current.push(parallaxTrigger);

    return () => {
      triggersRef.current.forEach((t) => t.kill());
      triggersRef.current = [];
    };
  }, []);

  return (
    <section
      ref={sectionRef}
      id="about"
      className="relative py-24 md:py-32 px-8 lg:px-16 overflow-hidden bg-[var(--pilat-cream)]"
    >
      <div className="relative z-10 max-w-7xl mx-auto">
        {/* Section layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left column - Images */}
          <div className="lg:col-span-5 relative">
            {/* Image 1 */}
            <div
              ref={image1Ref}
              className="relative w-full aspect-[3/4] overflow-hidden rounded-2xl group cursor-pointer shadow-lg"
              style={{ willChange: 'clip-path, transform' }}
            >
              <img
                src={aboutConfig.image1}
                alt={aboutConfig.image1Alt}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
            </div>

            {/* Image 2 - overlapping */}
            <div
              ref={image2Ref}
              className="relative w-2/3 aspect-[3/4] -mt-24 ml-auto mr-8 overflow-hidden rounded-2xl group cursor-pointer z-10 shadow-xl"
              style={{ willChange: 'clip-path, transform' }}
            >
              <img
                src={aboutConfig.image2}
                alt={aboutConfig.image2Alt}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
            </div>
          </div>

          {/* Right column - Content */}
          <div className="lg:col-span-7 flex flex-col justify-center lg:pl-8">
            {/* Tag */}
            <span className="tag mb-6">Sobre Nós</span>

            {/* Section title */}
            <h2
              ref={titleRef}
              className="text-3xl md:text-4xl lg:text-5xl text-[var(--pilat-dark)] font-normal leading-tight mb-8"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              <span className="title-line block">
                {aboutConfig.titleLine1}
              </span>
              <span className="title-line block">
                {aboutConfig.titleLine2}
              </span>
            </h2>

            {/* Accent line */}
            <div
              ref={lineRef}
              className="h-px bg-[var(--pilat-taupe)] mb-8"
              style={{ willChange: 'width' }}
            />

            {/* About text */}
            <p
              ref={textRef}
              className="text-base md:text-lg text-[var(--pilat-gray)] leading-relaxed mb-12"
            >
              {aboutConfig.description}
            </p>

            {/* Author section */}
            <div className="flex items-start gap-6">
              {/* Author image */}
              <div
                ref={authorImageRef}
                className="w-20 h-20 flex-shrink-0 overflow-hidden rounded-full border-2 border-[var(--pilat-taupe)]"
                style={{ willChange: 'transform, opacity' }}
              >
                <img
                  src={aboutConfig.authorImage}
                  alt={aboutConfig.authorName}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Author text */}
              <div ref={authorTextRef}>
                <p className="text-sm text-[var(--pilat-gray)] leading-relaxed italic">
                  "{aboutConfig.authorBio}"
                </p>
                <p className="text-sm font-medium text-[var(--pilat-dark)] mt-2">
                  {aboutConfig.authorName}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
