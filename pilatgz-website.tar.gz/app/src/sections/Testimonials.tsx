import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Quote } from 'lucide-react';
import { testimonialsConfig } from '../config';

gsap.registerPlugin(ScrollTrigger);

export function Testimonials() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);
  const triggersRef = useRef<ScrollTrigger[]>([]);

  if (!testimonialsConfig.title || testimonialsConfig.testimonials.length === 0) return null;

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    // Entry animation
    const trigger = ScrollTrigger.create({
      trigger: section,
      start: 'top 80%',
      onEnter: () => {
        const tl = gsap.timeline();

        // Title fade
        tl.fromTo(
          titleRef.current,
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.8, ease: 'power2.out' }
        );

        // Cards stagger
        cardsRef.current.forEach((card, i) => {
          if (card) {
            tl.fromTo(
              card,
              { y: 50, opacity: 0 },
              {
                y: 0,
                opacity: 1,
                duration: 0.6,
                ease: 'back.out(1.2)',
              },
              `-=${0.4 - i * 0.1}`
            );
          }
        });
      },
      once: true,
    });
    triggersRef.current.push(trigger);

    return () => {
      triggersRef.current.forEach((t) => t.kill());
      triggersRef.current = [];
    };
  }, []);

  return (
    <section
      ref={sectionRef}
      id="testimonials"
      className="relative py-24 md:py-32 px-8 lg:px-16 bg-[var(--pilat-beige)]"
    >
      <div className="max-w-6xl mx-auto">
        {/* Tag */}
        <span className="tag mb-4 block text-center">{testimonialsConfig.tag}</span>

        {/* Section title */}
        <h2
          ref={titleRef}
          className="text-3xl md:text-4xl lg:text-5xl text-[var(--pilat-dark)] font-normal text-center mb-16"
          style={{ fontFamily: "'Playfair Display', serif" }}
        >
          {testimonialsConfig.title}
        </h2>

        {/* Testimonial cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8">
          {testimonialsConfig.testimonials.map((testimonial, index) => (
            <div
              key={testimonial.id}
              ref={(el) => {
                cardsRef.current[index] = el;
              }}
              className="relative bg-[var(--pilat-cream)] rounded-2xl p-8 group hover:shadow-xl transition-all duration-500"
            >
              {/* Quote mark */}
              <Quote className="absolute top-6 right-6 w-10 h-10 text-[var(--pilat-taupe)] opacity-30" />

              {/* Quote text */}
              <p className="text-base text-[var(--pilat-gray)] leading-relaxed mb-8 relative z-10">
                "{testimonial.quote}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-4">
                {/* Avatar */}
                <div className="w-14 h-14 rounded-full overflow-hidden border-2 border-[var(--pilat-taupe)] flex-shrink-0">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Info */}
                <div>
                  <h4 className="text-sm font-medium text-[var(--pilat-dark)]">
                    {testimonial.name}
                  </h4>
                  <p className="text-xs text-[var(--pilat-gray)]">
                    {testimonial.title}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
