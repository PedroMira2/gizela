import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { quoteConfig } from '../config';

gsap.registerPlugin(ScrollTrigger);

export function Quote() {
  const sectionRef = useRef<HTMLElement>(null);
  const quoteRef = useRef<HTMLQuoteElement>(null);
  const attributionRef = useRef<HTMLParagraphElement>(null);
  const triggersRef = useRef<ScrollTrigger[]>([]);

  if (!quoteConfig.quote) return null;

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const trigger = ScrollTrigger.create({
      trigger: section,
      start: 'top 70%',
      onEnter: () => {
        const tl = gsap.timeline();

        // Quote words animation
        if (quoteRef.current) {
          const words = quoteRef.current.querySelectorAll('.word');
          tl.fromTo(
            words,
            { y: 30, opacity: 0 },
            {
              y: 0,
              opacity: 1,
              duration: 0.5,
              stagger: 0.05,
              ease: 'power2.out',
            }
          );
        }

        // Attribution fade
        tl.fromTo(
          attributionRef.current,
          { y: 15, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.5, ease: 'power2.out' },
          '-=0.2'
        );
      },
      once: true,
    });
    triggersRef.current.push(trigger);

    return () => {
      triggersRef.current.forEach((t) => t.kill());
      triggersRef.current = [];
    };
  }, []);

  const quoteWords = quoteConfig.quote.split(' ');

  return (
    <section
      ref={sectionRef}
      className="relative py-24 md:py-32 px-8 bg-[var(--pilat-cream)]"
    >
      <div className="max-w-4xl mx-auto text-center">
        {/* Decorative quote marks */}
        <div className="text-[120px] md:text-[180px] text-[var(--pilat-taupe)]/20 leading-none font-['Playfair_Display'] select-none -mb-16 md:-mb-24">
          "
        </div>

        <blockquote ref={quoteRef} className="relative z-10">
          <p
            className="text-2xl md:text-3xl lg:text-4xl text-[var(--pilat-dark)] font-normal leading-relaxed mb-8"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            {quoteWords.map((word, i) => (
              <span key={i} className="word inline-block mr-[0.3em]">
                {word}
              </span>
            ))}
          </p>
        </blockquote>

        <p
          ref={attributionRef}
          className="text-sm text-[var(--pilat-gray)]"
        >
          {quoteConfig.attribution}
        </p>
      </div>
    </section>
  );
}
