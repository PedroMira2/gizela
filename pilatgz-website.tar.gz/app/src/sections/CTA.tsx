import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ctaConfig } from '../config';

gsap.registerPlugin(ScrollTrigger);

export function CTA() {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const triggersRef = useRef<ScrollTrigger[]>([]);

  if (!ctaConfig.title) return null;

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    // Content animation
    const contentTrigger = ScrollTrigger.create({
      trigger: contentRef.current,
      start: 'top 75%',
      onEnter: () => {
        gsap.fromTo(
          contentRef.current,
          { x: -50, opacity: 0 },
          { x: 0, opacity: 1, duration: 0.8, ease: 'power2.out' }
        );
      },
      once: true,
    });
    triggersRef.current.push(contentTrigger);

    // Image animation
    const imageTrigger = ScrollTrigger.create({
      trigger: imageRef.current,
      start: 'top 75%',
      onEnter: () => {
        gsap.fromTo(
          imageRef.current,
          { clipPath: 'polygon(100% 0, 100% 0, 100% 100%, 100% 100%)' },
          {
            clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0 100%)',
            duration: 1,
            ease: 'expo.out',
          }
        );
      },
      once: true,
    });
    triggersRef.current.push(imageTrigger);

    return () => {
      triggersRef.current.forEach((t) => t.kill());
      triggersRef.current = [];
    };
  }, []);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      className="relative py-0 overflow-hidden bg-[var(--pilat-beige)]"
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 min-h-[600px]">
        {/* Content */}
        <div
          ref={contentRef}
          className="flex flex-col justify-center px-8 lg:px-16 py-16 lg:py-24"
        >
          <h2
            className="text-3xl md:text-4xl lg:text-5xl text-[var(--pilat-dark)] font-normal mb-6"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            {ctaConfig.title}
          </h2>
          <p className="text-base md:text-lg text-[var(--pilat-gray)] mb-10 leading-relaxed">
            {ctaConfig.subtitle}
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <a
              href="#contact"
              onClick={(e) => handleNavClick(e, '#contact')}
              className="btn-primary"
            >
              {ctaConfig.primaryCta}
            </a>
            <a
              href="#contact"
              onClick={(e) => handleNavClick(e, '#contact')}
              className="btn-secondary"
            >
              {ctaConfig.secondaryCta}
            </a>
          </div>
        </div>

        {/* Image */}
        <div
          ref={imageRef}
          className="relative h-[400px] lg:h-auto"
          style={{ willChange: 'clip-path' }}
        >
          <img
            src={ctaConfig.image}
            alt="CTA"
            className="w-full h-full object-cover"
          />
        </div>
      </div>
    </section>
  );
}
