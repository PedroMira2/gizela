import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowUpRight, Clock, Calendar } from 'lucide-react';
import { blogConfig } from '../config';

gsap.registerPlugin(ScrollTrigger);

export function Blog() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const descRef = useRef<HTMLParagraphElement>(null);
  const postsRef = useRef<(HTMLElement | null)[]>([]);
  const triggersRef = useRef<ScrollTrigger[]>([]);

  if (!blogConfig.title || blogConfig.posts.length === 0) return null;

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const trigger = ScrollTrigger.create({
      trigger: section,
      start: 'top 80%',
      onEnter: () => {
        const tl = gsap.timeline();

        // Title fade
        tl.fromTo(
          titleRef.current,
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, ease: 'power2.out' }
        );

        // Description fade
        tl.fromTo(
          descRef.current,
          { y: 20, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.6, ease: 'power2.out' },
          '-=0.4'
        );

        // Posts stagger
        postsRef.current.forEach((post, i) => {
          if (post) {
            tl.fromTo(
              post,
              { y: 50, opacity: 0 },
              {
                y: 0,
                opacity: 1,
                duration: 0.6,
                ease: 'back.out(1.2)',
              },
              `-=${0.4 - i * 0.1}`
            );
          }
        });
      },
      once: true,
    });
    triggersRef.current.push(trigger);

    return () => {
      triggersRef.current.forEach((t) => t.kill());
      triggersRef.current = [];
    };
  }, []);

  return (
    <section
      ref={sectionRef}
      id="blog"
      className="relative py-24 md:py-32 px-8 lg:px-16 bg-[var(--pilat-cream)]"
    >
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-12">
          <div>
            <span className="tag mb-4 block">BLOG</span>
            <h2
              ref={titleRef}
              className="text-3xl md:text-4xl lg:text-5xl text-[var(--pilat-dark)] font-normal mb-4"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              {blogConfig.title}
            </h2>
            <p ref={descRef} className="text-base md:text-lg text-[var(--pilat-gray)] max-w-xl">
              {blogConfig.subtitle}
            </p>
          </div>
          <button className="btn-secondary mt-6 md:mt-0 self-start">
            {blogConfig.allPostsLabel}
          </button>
        </div>

        {/* Posts grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {blogConfig.posts.map((post, index) => (
            <article
              key={post.id}
              ref={(el) => {
                postsRef.current[index] = el;
              }}
              className="group cursor-pointer"
            >
              {/* Image */}
              <div className="post-image relative aspect-[4/3] overflow-hidden rounded-2xl mb-5">
                <img
                  src={post.image}
                  alt={post.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[var(--pilat-dark)]/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              </div>

              {/* Content */}
              <div className="post-content">
                {/* Meta */}
                <div className="flex items-center gap-4 text-xs text-[var(--pilat-gray)] mb-3">
                  <span className="px-3 py-1 bg-[var(--pilat-beige)] rounded-full">
                    {post.category}
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {post.date}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {blogConfig.readTimePrefix}{post.readTime}
                  </span>
                </div>

                {/* Title */}
                <h3
                  className="text-lg md:text-xl text-[var(--pilat-dark)] font-normal mb-2 group-hover:text-[var(--pilat-taupe)] transition-colors duration-300"
                  style={{ fontFamily: "'Playfair Display', serif" }}
                >
                  {post.title}
                </h3>

                {/* Excerpt */}
                <p className="text-sm text-[var(--pilat-gray)] mb-4 line-clamp-2">
                  {post.excerpt}
                </p>

                {/* Read more */}
                <span className="inline-flex items-center gap-2 text-sm text-[var(--pilat-dark)] group-hover:text-[var(--pilat-taupe)] transition-colors duration-300">
                  {blogConfig.readMoreLabel}
                  <ArrowUpRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-1" />
                </span>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
