import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { instructorsConfig } from '../config';

gsap.registerPlugin(ScrollTrigger);

export function Instructors() {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);
  const triggersRef = useRef<ScrollTrigger[]>([]);

  if (!instructorsConfig.title) return null;

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    // Header animation
    const headerTrigger = ScrollTrigger.create({
      trigger: headerRef.current,
      start: 'top 80%',
      onEnter: () => {
        gsap.fromTo(
          headerRef.current,
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.8, ease: 'power2.out' }
        );
      },
      once: true,
    });
    triggersRef.current.push(headerTrigger);

    // Cards stagger animation
    const cardsTrigger = ScrollTrigger.create({
      trigger: cardsRef.current,
      start: 'top 75%',
      onEnter: () => {
        const cards = cardsRef.current?.querySelectorAll('.instructor-card');
        if (cards) {
          gsap.fromTo(
            cards,
            { y: 50, opacity: 0 },
            {
              y: 0,
              opacity: 1,
              duration: 0.6,
              stagger: 0.2,
              ease: 'back.out(1.2)',
            }
          );
        }
      },
      once: true,
    });
    triggersRef.current.push(cardsTrigger);

    return () => {
      triggersRef.current.forEach((t) => t.kill());
      triggersRef.current = [];
    };
  }, []);

  return (
    <section
      ref={sectionRef}
      id="instructors"
      className="relative py-24 md:py-32 px-8 lg:px-16 bg-[var(--pilat-cream)]"
    >
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div ref={headerRef} className="text-center mb-16">
          <span className="tag mb-4 block">{instructorsConfig.tag}</span>
          <h2
            className="text-3xl md:text-4xl lg:text-5xl text-[var(--pilat-dark)] font-normal mb-6"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            {instructorsConfig.title}
          </h2>
          <p className="text-base md:text-lg text-[var(--pilat-gray)] max-w-2xl mx-auto">
            {instructorsConfig.subtitle}
          </p>
        </div>

        {/* Cards Grid */}
        <div
          ref={cardsRef}
          className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12 max-w-4xl mx-auto"
        >
          {instructorsConfig.instructors.map((instructor) => (
            <div
              key={instructor.id}
              className="instructor-card group bg-[var(--pilat-beige)] rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-500"
            >
              <div className="grid grid-cols-1 sm:grid-cols-3">
                {/* Image */}
                <div className="relative aspect-square sm:aspect-auto overflow-hidden">
                  <img
                    src={instructor.image}
                    alt={instructor.name}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                </div>

                {/* Content */}
                <div className="sm:col-span-2 p-6 flex flex-col justify-center">
                  <h3
                    className="text-xl text-[var(--pilat-dark)] font-normal mb-1"
                    style={{ fontFamily: "'Playfair Display', serif" }}
                  >
                    {instructor.name}
                  </h3>
                  <p className="text-sm text-[var(--pilat-taupe)] mb-4">
                    {instructor.role}
                  </p>
                  <p className="text-sm text-[var(--pilat-gray)] mb-4 line-clamp-3">
                    {instructor.bio}
                  </p>

                  {/* Specialties */}
                  <div className="flex flex-wrap gap-2">
                    {instructor.specialties.map((specialty, idx) => (
                      <span
                        key={idx}
                        className="text-xs px-3 py-1 bg-[var(--pilat-cream)] text-[var(--pilat-gray)] rounded-full"
                      >
                        {specialty}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
