import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Clock, Zap, Users } from 'lucide-react';
import { modalitiesConfig } from '../config';

gsap.registerPlugin(ScrollTrigger);

export function Modalities() {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);
  const triggersRef = useRef<ScrollTrigger[]>([]);

  if (!modalitiesConfig.title) return null;

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    // Header animation
    const headerTrigger = ScrollTrigger.create({
      trigger: headerRef.current,
      start: 'top 80%',
      onEnter: () => {
        gsap.fromTo(
          headerRef.current,
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.8, ease: 'power2.out' }
        );
      },
      once: true,
    });
    triggersRef.current.push(headerTrigger);

    // Cards stagger animation
    const cardsTrigger = ScrollTrigger.create({
      trigger: cardsRef.current,
      start: 'top 75%',
      onEnter: () => {
        const cards = cardsRef.current?.querySelectorAll('.modality-card');
        if (cards) {
          gsap.fromTo(
            cards,
            { y: 50, opacity: 0 },
            {
              y: 0,
              opacity: 1,
              duration: 0.6,
              stagger: 0.15,
              ease: 'back.out(1.2)',
            }
          );
        }
      },
      once: true,
    });
    triggersRef.current.push(cardsTrigger);

    return () => {
      triggersRef.current.forEach((t) => t.kill());
      triggersRef.current = [];
    };
  }, []);

  return (
    <section
      ref={sectionRef}
      id="modalities"
      className="relative py-24 md:py-32 px-8 lg:px-16 bg-[var(--pilat-beige)]"
    >
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div ref={headerRef} className="text-center mb-16">
          <span className="tag mb-4 block">{modalitiesConfig.tag}</span>
          <h2
            className="text-3xl md:text-4xl lg:text-5xl text-[var(--pilat-dark)] font-normal mb-6"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            {modalitiesConfig.title}
          </h2>
          <p className="text-base md:text-lg text-[var(--pilat-gray)] max-w-2xl mx-auto">
            {modalitiesConfig.subtitle}
          </p>
        </div>

        {/* Cards Grid */}
        <div
          ref={cardsRef}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8"
        >
          {modalitiesConfig.modalities.map((modality) => (
            <div
              key={modality.id}
              className="modality-card group bg-[var(--pilat-cream)] rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-500"
            >
              {/* Image */}
              <div className="relative aspect-[3/4] overflow-hidden">
                <img
                  src={modality.image}
                  alt={modality.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[var(--pilat-dark)]/60 via-transparent to-transparent" />
                
                {/* Title overlay */}
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <h3
                    className="text-xl md:text-2xl text-white font-normal mb-2"
                    style={{ fontFamily: "'Playfair Display', serif" }}
                  >
                    {modality.title}
                  </h3>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <p className="text-sm text-[var(--pilat-gray)] mb-4 line-clamp-3">
                  {modality.description}
                </p>

                {/* Meta info */}
                <div className="flex items-center gap-4 text-xs text-[var(--pilat-gray)] mb-4">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {modality.duration}
                  </span>
                  <span className="flex items-center gap-1">
                    <Zap className="w-3 h-3" />
                    {modality.intensity}
                  </span>
                  <span className="flex items-center gap-1">
                    <Users className="w-3 h-3" />
                    {modality.benefits.length} benefícios
                  </span>
                </div>

                {/* Benefits */}
                <ul className="space-y-1">
                  {modality.benefits.slice(0, 3).map((benefit, idx) => (
                    <li
                      key={idx}
                      className="text-xs text-[var(--pilat-gray)] flex items-center gap-2"
                    >
                      <span className="w-1 h-1 rounded-full bg-[var(--pilat-taupe)]" />
                      {benefit}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
